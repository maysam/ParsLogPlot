﻿namespace ParsLogPlot {


    partial class logplotDataSet1
    {
        partial class configurationDataTable
        {
        }
    }
}
